const express = require('express');

const router = express.Router();

const Publication = require('../models/publication.model');
